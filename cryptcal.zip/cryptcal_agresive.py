#!/bin/python3

'''

Author : mucomplex
requirement : 
pip install python-binance
pip install colored

'''

'''
1.false postive for macd just want go downtrends.
2.cek for bollinger band support to buy
'''

import os
import sys
import argparse
import requests
import json
import time
from colored import fg,bg,attr
from binance.client import Client
from binance.exceptions import BinanceAPIException


#Config binance
api_key     =""
api_secret  =""
#Config taapi
api_taapi   =""
exchange    ="binance"
interval    ="1m"

#Default config
sleep_timer = 1
No_trading_per_coin = 1
bot_test_enable = True

'''
e.g main function defined.
results = crypto_currency(args.symbol[0],args.usdt[0])
results.overall_results()
results.pull_user_data()

results.define_buy()
results.percentage_risk()
results.bot_buy_check()
results.bot_sell_check()


'''
class crypto_currency:

    def __init__(self,symbol,usdt):
        #setting API
        self.client = Client(api_key,api_secret)
        self.symbol_taapi = (symbol + "/USDT").upper()
        self.symbol = self.symbol_taapi.replace('/','')

        #user info
        self.balance = 0

        #user input defined.
        self.usdt = usdt

        #define results
        self.No_of_Trade =0
        self.Win         =0
        self.Lose        =0

        #define bband value
        self.valueUpperBand  =0 
        self.valueMiddleBand =0
        self.valueLowerBand  =0 

        #profit_count
        self.total_profit = 0

        #pre-defined risk
        self.net_profit = 0 
        self.net_loss   = 0 
        self.set_profit = 0 
        self.set_loss   = 0 

        #pre-defined risk 2
        self.buy_price      = 0
        self.profit_price   = 0
        self.med_price      = 0
        self.loss_price     = 0
        self.trade_unit     = 0



        #bot setting
        self.Trading = []

    def pull_user_data(self):
        self.usdt_asset()
        self.value= self.symbol_price()
        self.unit = self.unit_check()


    def overall_results(self):
        print('%sWin         : %s%s' %(fg(10),attr(0),self.Win))
        print('%sLose        : %s%s' %(fg(9),attr(0),self.Lose))
        print('%sTrade       : %s%s' %(fg(117),attr(0),self.No_of_Trade))
        print('%sProfit      : %s%s' %(fg(165),attr(0),self.total_profit))
        print('%sPer-Trade   : %s%s' %(fg(43),attr(0),len(self.Trading)))
        print('%sBuy price   : %s%s' %(fg(117),attr(0),self.buy_price))
        print('%sprofit price: %s%s' %(fg(10),attr(0),self.profit_price))
        print('%smed price   : %s%s' %(fg(11),attr(0),self.med_price))
        print('%sloss price  : %s%s' %(fg(9),attr(0),self.loss_price))
        print('%strade unit  : %s%s' %(fg(43),attr(0),self.trade_unit))

    def define_buy(self):
        #indicators
        self.hammer             = self.pattern_hammer()
        self.invertedhammer     = self.pattern_invertedhammer()
        self.engulfing          = self.pattern_engulfing()
        self.morningstar        = self.pattern_morningstar()
        self.sma25_buy          = self.get_sma25_check_buy()
        self.sma50_buy          = self.get_sma50_check_buy()
        self.sma100_buy         = self.get_sma100_check_buy()
        self.rsi_buy_uptrend    = self.get_rsi_check_buy_uptrend()
        self.rsi_buy_downtrend  = self.get_rsi_check_buy_downtrend()
        self.bbands_buy         = self.get_bbands_check_buy()
        self.macd_buy           = self.get_macd_check_buy()
        self.macd_p4            = self.get_macd_check_buy_past4()
        self.qstick             = self.pattern_qstick()
        self.qstick25           = self.pattern_qstick25()

        #special case indicator
        self._3whitesoldiers    = self.pattern_3whitesoldiers()

    def bot_buy_check(self):
        '''
        buy strategy.
        (strategy 1 and 2 is for up trend)
        (strategy 3 is for downtrend)
        1- hammer,invertedhammer,engulfing,morningstar,3whitesoldiers which either +0.03 higher and  -0.03 lower from moving average(25,50,100).
        2- hammer,invertedhammer,engulfing,morningstar,3whitesoldiers which either lower or equal to low bollinger band.
        3- hammer,invertedhammer,engulfing,morningstar,3whitesoldiers occur on 10% below moving average.
        4- strategy 1,2 and 3 must agreed with rsi uptrend or rsi downtrend or macd.
        5- Special indicators are defined separately.

        #logic
        (hammer || invertedhammer || engulfing || morningstar || 3whitesoldiers) && (((sma_check || bband) && uptrend qstick) or (sma25 && downtrend)) && ((rsi uptrend) or (rsi downrend) or macd)

        or
        1. threewhitesoldiers on downtrend.
        2. morning star either up or down trend.

        enable rsi and qstick, macd and macd4 will strict buy mechanism.
        '''
        if(

                ((self.hammer == True or self.invertedhammer == True or self.engulfing == True or self.morningstar == True or self._3whitesoldiers) and
                #buy between +0.03 and -0.03 sma25,50,100 above
                ((((self.sma25_buy +(self.sma25_buy     *0.03)) >= self.value and self.value >= (self.sma25_buy  - (self.sma25_buy * 0.03)) or
                  (self.sma50_buy + (self.sma50_buy   *0.03)) >= self.value and self.value >= (self.sma50_buy  - (self.sma50_buy * 0.03)) or 
                  (self.sma100_buy + (self.sma100_buy *0.03)) >= self.value and self.value >= (self.sma100_buy - (self.sma100_buy * 0.03)) or
                #bband lower
                (self.bbands_buy == True))) or
                #downtrend buy 10% below 25 sma.
                ((self.sma25_buy - (self.sma25_buy * 0.1)) >= self.value and self.qstick == False)) and 
                #either rsi,macd.
                #rsi uptrend set to 35
                #((self.rsi_buy_uptrend == True and self.qstick25==True) or
                ((self.rsi_buy_uptrend == True) or
                #rsi downtrend set to 25
                #(self.rsi_buy_downtrend == True and self.qstick25==False) or
                (self.rsi_buy_downtrend == True) or
                 #(self.macd_buy == True and self.macd_p4 == True)
                (self.macd_buy == True)
                 )
                ) or
                
                #special case indicator here.
                #Three with soldiers should be with downtrend.
                (self._3whitesoldiers == True) or
                #morningstar
                (self.morningstar == True)
                ):

            #if bot enabled.
            if(float(self.balance) > self.usdt or bot_test_enable):
                #defined 1 trade per coin.
                if(len(self.Trading) < No_trading_per_coin):
                    for decimal in range(6,-1,-1):
                        if(decimal == 0):
                            valid_unit_amount = int(self.unit)
                        else:
                            valid_unit_amount = round(self.unit,decimal)
                        #if candle move to fast, can use self.value * 0.0005 to success buy on time.
                        #if(self.order_buy_price(valid_unit_amount,self.value) != -1013 or bot_test_enable):
                        #if(self.order_buy_price(valid_unit_amount,self.value + (self.value * 0.0005)) != -1013 or bot_test_enable):
                        if(bot_test_enable):
                            print('%sSuccessful buy!.%s' %(fg(43),attr(0)))

                            Trading_Dict = {
                                "Id": self.No_of_Trade,
                                "buy_price": self.value,
                                "high_price": self.set_profit,
                                "med_price": self.valueMiddleBand,
                                "low_price": self.set_loss,
                                "unit_amount" : valid_unit_amount,
                                }

                            #define the price.
                            self.buy_price      = self.value
                            self.profit_price   = self.set_profit 
                            self.med_price      = self.valueMiddleBand
                            self.loss_price     = self.set_loss
                            self.trade_unit     = valid_unit_amount

                            #add buy to list.
                            self.Trading.append(Trading_Dict)
                            self.No_of_Trade += 1 
                            break
                        else:
                            print('%sAttempt to buy.%s' %(fg(43),attr(0)))



    def bot_sell_check(self):
        for sell_check in self.Trading:
            #check for downtrand and mid bband, if true then sell.
            #valid unit is to subtract binance fee
            valid_unit_amount = sell_check["unit_amount"] - (sell_check["unit_amount"] * 0.002)
            '''
            put gap 0.02 after medium bband.
            - med_price must large than buy_price.
            - disable selling on med, cannot gain full potentials high price.
            - this code is not up to date.

            '''
            '''

            if(self.value >  sell_check['med_price'] and (sell_check['med_price'] > sell_check['buy_price'])
                    and self.qstick25 == False and self.value > (sell_check['buy_price'] + (sell_check['buy_price'] * 0.02)) ):
                #set sell order
                self.order_sell_price(valid_unit_amount,self.value)

                self.Win +=1
                self.total_profit += ((self.value - sell_check['buy_price']) * sell_check["unit_amount"])
                self.Trading.remove(sell_check)
            '''

            if(self.value > sell_check['high_price']):
                #set sell order
                for decimal in range(6,-1,-1):
                    if(decimal == 0):
                        valid_unit_amount = int(valid_unit_amount)
                    else:
                        valid_unit_amount = round(valid_unit_amount,decimal)
                    #if candle move to fast, can use self.value * 0.0005 to success sell on time.
                    #if(self.order_sell_price(valid_unit_amount,self.value) != -1013 or bot_test_enable):
                    if(self.order_sell_price(valid_unit_amount,self.value - (self.value * 0.0005)) != -1013 or bot_test_enable):
                        print('%sSuccessful sell :) .%s' %(fg(43),attr(0)))
                        self.Win +=1
                        self.total_profit += ((self.value - sell_check['buy_price']) * sell_check["unit_amount"])
                        self.Trading.remove(sell_check)
                        break
                    else:
                        print('%sAttempt to sell :) .%s' %(fg(200),attr(0)))

            if(self.value < sell_check['low_price']):
                #set sell order
                for decimal in range(6,-1,-1):
                    if(decimal == 0):
                        valid_unit_amount = int(valid_unit_amount)
                    else:
                        valid_unit_amount = round(valid_unit_amount,decimal)
                    #if candle move to fast, can use self.value * 0.001 to success sell on time.
                    #if(self.order_sell_price(valid_unit_amount,self.value) != -1013 or  bot_test_enable):
                    if(self.order_sell_price(valid_unit_amount,self.value - (self.value * 0.001)) != -1013 or bot_test_enable):
                        print('%sSuccessful sell :( .%s' %(fg(43),attr(0)))
                        self.Lose +=1
                        self.total_profit -= ((sell_check['buy_price'] - self.value) * sell_check["unit_amount"])
                        self.Trading.remove(sell_check)
                        break
                    else:
                        print('%sAttempt to sell :( .%s' %(fg(200),attr(0)))



    def unit_check(self):
        #unit error handling.
        #check if usdt is larger than current price and 0.1
        if(self.usdt > self.value and self.value > 0.1):
                unit = round(self.usdt / self.value,1)
        #check if current price less than 0.1
        elif(self.value < 0.1):
                unit = round(self.usdt / self.value,0)
        #check if current price larger than usdt.
        else:
                unit = round(self.usdt / self.value,4)
        print("current unit: " + str(unit))
        return unit


    def usdt_asset(self):
        try:
            balance = self.client.get_asset_balance(asset='USDT')
            self.balance = balance["free"]
            print("USDT balance: %s$%s%s" % (fg(220),balance["free"],attr(0)))
        except:
            print("USDT balance: Server reset.")

    def order_buy_price(self,unit_quantity,unit_price):
        try:
            self.client.order_limit_buy(symbol=self.symbol,quantity=unit_quantity,price=unit_price)
        except BinanceAPIException as e:
            #print(e.message)
            #print(e.code)
            return e.code

    def order_sell_price(self,unit_quantity,unit_price):
        try:
            self.client.order_limit_sell(symbol=self.symbol,quantity=unit_quantity,price=unit_price)
        except BinanceAPIException as e:
            #print(e.message)
            #print(e.code)
            return e.code


    #getting price function
    def symbol_price(self):
        try:
            r = requests.get('https://api.binance.com/api/v3/ticker/price?symbol='+ self.symbol)
            value = json.loads(r.text)
            current_price = round(float(value["price"]),5)
            print("symbol      : " + value["symbol"])
            print("price       : %s%s%s" % (fg(41),str(current_price),attr(0)))
            return current_price
        except:
            print("price       : %s%s%s" % (fg(11),"Not Available.",attr(0)))
            return 0



    #risk calculation
    def percentage_risk(self):
        self.net_profit = round((self.value * 0.02),5)
        self.net_loss   = round((self.value * 0.01),5)
        self.set_profit = round(self.value + self.net_profit,5)
        self.set_loss   = round(self.value - self.net_loss,5)
        print('profit set  : %s%s%s' % (fg(10),str(self.set_profit),attr(0)))
        print('loss set    : %s%s%s' % (fg(9),str(self.set_loss),attr(0)))
        print('profit (2R) : $%s' %(round(self.net_profit * self.trade_unit,4)))
        print('loss   (1R) : $%s' %(round(self.net_loss * self.trade_unit,4)))

    #--------------------------------------------------------------- default Api -------------------------------------------------------
    '''
    period is set 10 for per minutes.
    period 25 is to validate with sell price.
    '''
    def pattern_qstick(self):
        endpoint = "https://api.taapi.io/qstick"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'period':10}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result          = json.loads(response.text)
        except:
            return False
        if(result["value"] > 0):
                print('%s[+]qstick10 : Uptrend%s ' %(fg(10),attr(0)))
                return True
        else:
            print('%s[-]qstick10 : Downtrend%s ' %(fg(9),attr(0)))
            return False

    def pattern_qstick25(self):
        endpoint = "https://api.taapi.io/qstick"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'period':25}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result          = json.loads(response.text)
        except:
            return False
        if(result["value"] > 0):
                print('%s[+]qstick25 : Uptrend%s ' %(fg(10),attr(0)))
                return True
        else:
            print('%s[-]qstick25 : Downtrend%s ' %(fg(9),attr(0)))
            return False


    #--------------------------------------------------------------- default Api -------------------------------------------------------

    #--------------------------------------------------------------- buying mechanism --------------------------------------------------
    '''
    all pattern mechanism is set to previous 3 candle stick (backtracks 3) to match with MACD and RSI.
    '''
    def pattern_hammer(self):
        endpoint = "https://api.taapi.io/hammer"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtracks':3}
        try:
            response = requests.get(url=endpoint,params = parameters)
            results   = json.loads(response.text)
        except:
            return False
        for result in results:
            if(result["value"] == 100):
                print('%s[+]hammer   : Success%s ' %(fg(10),attr(0)))
                return True
        print('%s[-]hammer   : Failed%s ' %(fg(9),attr(0)))
        return False

    def pattern_invertedhammer(self):
        endpoint = "https://api.taapi.io/invertedhammer"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtracks':3}
        try:
            response = requests.get(url=endpoint,params = parameters)
            results   = json.loads(response.text)
        except:
            return False
        for result in results:
            if(result["value"] == 100):
                print('%s[+]Ihammer  : Success%s ' %(fg(10),attr(0)))
                return True
        print('%s[-]Ihammer  : Failed%s ' %(fg(9),attr(0)))
        return False

    def pattern_engulfing(self):
        endpoint = "https://api.taapi.io/engulfing"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtracks':3}
        try:
            response = requests.get(url=endpoint,params = parameters)
            results   = json.loads(response.text)
        except:
            return False
        for result in results:
            if(result["value"] == 100):
                print('%s[+]engulf   : Success%s ' %(fg(10),attr(0)))
                return True
        print('%s[-]engulf   : Failed%s ' %(fg(9),attr(0)))
        return False


    def pattern_morningstar(self):
        endpoint = "https://api.taapi.io/morningstar"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtracks':3}
        try:
            response = requests.get(url=endpoint,params = parameters)
            results   = json.loads(response.text)
        except:
            return False
        for result in results:
            if(result["value"] == 100):
                print('%s[+]ms       : Success%s ' %(fg(10),attr(0)))
                return True
        print('%s[-]ms       : Failed%s ' %(fg(9),attr(0)))
        return False


    def pattern_3whitesoldiers(self):
        endpoint = "https://api.taapi.io/3whitesoldiers"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtracks':3}
        try:
            response = requests.get(url=endpoint,params = parameters)
            results   = json.loads(response.text)
        except:
            return False
        for result in results:
            if(result["value"] == 100):
                print('%s[+]3ws      : Success%s ' %(fg(10),attr(0)))
                return True
            print('%s[-]3ws      : Failed%s ' %(fg(9),attr(0)))
            return False

    '''
    MACD is succeed when histogram is positive, MACD > signalMACD, and it still lower than 0
    -remove the comment to enable value display.

    macd past 3 is to make sure we not buy on high false positive value, as value MACD is set 0.1 higher then signal value.
    '''
    def get_macd_check_buy(self):
        endpoint = "https://api.taapi.io/macd"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return False
        if(result["valueMACDHist"] < 0 and ((result["valueMACD"] + abs(result["valueMACD"] * 0.1)) > result["valueMACDSignal"])):
            #print('%s[+]MACD %s : Success%s ' %(fg(10),round(result["valueMACDHist"],6),attr(0)))
            print('%s[+]MACD     : Success%s ' %(fg(10),attr(0)))
            return True
        else:
            #print('%s[-]MACD %s : Failed%s ' %(fg(9),round(result["valueMACDHist"],6),attr(0)))
            print('%s[-]MACD     : Failed%s ' %(fg(9),attr(0)))
            return False

    def get_macd_check_buy_past4(self):
        endpoint = "https://api.taapi.io/macd"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtrack':4}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return False
        if(result["valueMACDHist"] < 0):
            #print('%s[+]MACD_p4 %s : Success%s ' %(fg(10),round(result["valueMACDHist"],6),attr(0)))
            print('%s[+]MACD_p4  : Success%s ' %(fg(10),attr(0)))
            return True
        else:
            #print('%s[-]MACD_p4 %s : Failed%s ' %(fg(9),round(result["valueMACDHist"],6),attr(0)))
            print('%s[-]MACD_p4  : Failed%s ' %(fg(9),attr(0)))
            return False


    '''
    Bollinger band defined.
    for Lowerband, Im put 5% above to increase the chance.
    -disable the comment to show the value.
    '''
    def get_bbands_check_buy(self):
        endpoint = "https://api.taapi.io/bbands"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return False
        self.valueUpperBand     = round(result["valueUpperBand"],5)
        self.valueMiddleBand    = round(result["valueMiddleBand"],5)
        self.valueLowerBand     = round(result["valueLowerBand"],5)
        if(result["valueLowerBand"]  >= self.value):
            #print('%s[+]bbands %s : Success%s' %(fg(10),self.valueLowerBand,attr(0)))
            print('%s[+]bbands   : Success%s' %(fg(10),attr(0)))
            return True
        elif(result["valueMiddleBand"] > self.value):
            print('%s[=]bbands   : Normal%s ' %(fg(142),attr(0)))
            return False
        else:
            print('%s[-]bbands   : Failed%s '%(fg(9),attr(0)))
            return False

    # Need to check the trend if its up or down for sma25,50,100.
    def get_sma25_check_buy(self):
        endpoint = "https://api.taapi.io/sma"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'optInTimePeriod':25}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return 0
        return result["value"]

    def get_sma50_check_buy(self):
        endpoint = "https://api.taapi.io/sma"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'optInTimePeriod':50}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return 0
        return result["value"]

    def get_sma100_check_buy(self):
        endpoint = "https://api.taapi.io/sma"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'optInTimePeriod':100}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return 0
        return result["value"]

    '''
    rsi is set to previous 3 candle (backtrack) to get optimise amount and pairing with MACD
    - remove the comment to enable value display.
    '''
    def get_rsi_check_buy_uptrend(self):
        endpoint = "https://api.taapi.io/rsi"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtrack':3}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return False
        if(result["value"] > 80):
            #print('%s[-]RSI  %s:Failed%s ' %(fg(9),round(result["value"],6),attr(0)))
            print('%s[-]RSI up   : Failed%s ' %(fg(9),attr(0)))
            return False
        elif(result["value"] <= 35):
            #print('%s[+]RSI  %s:Success%s' %(fg(10),round(result["value"],6),attr(0)))
            print('%s[+]RSI up   : Success%s' %(fg(10),attr(0)))
            return True
        else:
            #print('%s[=]RSI  %s:Normal%s ' %(fg(142),round(result["value"],6),attr(0)))
            print('%s[=]RSI up   : Normal%s ' %(fg(142),attr(0)))
            return False

    def get_rsi_check_buy_downtrend(self):
        endpoint = "https://api.taapi.io/rsi"
        parameters = {'secret':api_taapi,'exchange':exchange,'symbol':self.symbol_taapi,'interval':interval,'backtrack':3}
        try:
            response = requests.get(url=endpoint,params = parameters)
            result   = json.loads(response.text)
        except:
            return False
        if(result["value"] > 80):
            #print('%s[-]RSI  %s:Failed%s ' %(fg(9),round(result["value"],6),attr(0)))
            print('%s[-]RSI down : Failed%s ' %(fg(9),attr(0)))
            return False
        elif(result["value"] <= 25):
            #print('%s[+]RSI  %s:Success%s' %(fg(10),round(result["value"],6),attr(0)))
            print('%s[+]RSI down : Success%s' %(fg(10),attr(0)))
            return True
        else:
            #print('%s[=]RSI  %s:Normal%s ' %(fg(142),round(result["value"],6),attr(0)))
            print('%s[=]RSI down : Normal%s ' %(fg(142),attr(0)))
            return False


    #--------------------------------------------------------------- buying mechanism --------------------------------------------------
    #--------------------------------------------------------------- selling mechanism --------------------------------------------------

    #--------------------------------------------------------------- selling mechanism --------------------------------------------------

#define argparse
parser = argparse.ArgumentParser()
parser.add_argument('symbol',nargs='+',help='place pair symbol e.g btc/usdt .')
parser.add_argument('usdt',nargs='+',type=float,help='usdt amount you want to trade.')
parser.add_argument('--execute',help='run a test for bot.')
parser.add_argument('--repeate',help='keep it running.')
args = parser.parse_args()

#input checking
if(args.usdt[0] <= 10):
    print("usdt price must be higher than 10$.")
    exit()

#main function
results = crypto_currency(args.symbol[0],args.usdt[0])
def main():
    print('--------------------------------')
    results.overall_results()
    results.pull_user_data()
    results.define_buy()
    results.percentage_risk()
    results.bot_buy_check()
    results.bot_sell_check()
    print('--------------------------------')

#loop case
while(args.repeate == 'true'):
    try:
        main()
    except Exception as e:
        print(e)
    time.sleep(sleep_timer)

#non-loop
if(args.repeate == None):
    main()
